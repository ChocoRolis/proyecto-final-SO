# Código fuente del proyecto

## Manuales

`server.py`: [manserver.md](../man/man_server.md)
`client_gui.py`: [man_clientgui.md](../man/man_guiclient.md)
