# Manuales 

Para no morir intentando leer y entender el codigo a secas
